---
layout: post
title: Major Updates
excerpt_separator: <!--more-->
---

## Update Num 1
I've built a couple of things since my last post. Namely my [threeinthree web app](https://github.com/seerocode/threeinthree) for the Capital One Engineering Summit application.

P.S. My app got me a spot in the Capital One Engineeering Summit. Wahoooo!!

Since I've built it, I have had the opportunity to use it 4 times. By opportunity I mean, I have needed to use it. But, guess what? A vital feature is missing and this is why testing is important. I'm looking to add HTML5 location feature to it to make it much easier to use.

## Update Num 2
I finished my web scraper some time ago but when is anything really finished? I've been building on it to make it more efficient and the code more readable (i.e. to others eyes and not just mine) and I've found a happy place. Next up is creating a web interface to map and pool all this data into. I love this!

## Update Num 3
I created the first iteration of the website for a nonprofit I'm founding. More details to come. [Link here](http://pocketsense.org/)

## Update Num 4
I am currently working through the design of a web app for the Lehman NSBE chapter that will serve sort of as our information hub. Starting small by building one feature which includes Slack app authentication to log into a test bank.

I will come back to talk about update num 2 more in depth. Didn't want to keep this blog dead for too long. That's it for now! 
