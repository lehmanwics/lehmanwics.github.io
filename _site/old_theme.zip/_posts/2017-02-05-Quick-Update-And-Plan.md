---
layout: post
title: Quick Update & Plan
excerpt_separator: <!--more-->
---

30 days are up and my progress has been very disappointing for several reasons, the main one being that I did not finish the projects I set out for myself. This was mainly due to poor time management and planning coupled with other responsibilities I was occupied with.

As I said in my previous post, I have a plan to tackle some part of that issue. It's not over yet.

My goal to complete the next two Java projects still stands along with a few other projects I have in mind. I will come back to those two projects later this year but right now, I have a few things I want to tackle first.

The first is learning Python for data science. 

<!--more-->

But Ro, you're still learning Java! 
So what, imaginary person?!

I learned Ruby before I learned Java, and I learned Javascript before I got to Java. None of these languages are exactly the same but moving between multiple languages even if I am not an expert is extremely valuable for me. What I know from one language I can easily transfer into learning another and it has helped me immensely with understanding how say Java works vs how Ruby works.

So, I am going to start learning Python regardless, on top of still getting past beginner level in Java. This I will be occupied with over the next 3 months. I haven't decided on a Python capstone project for myself to consolidate what I will have learned so that's to follow as well.

The next thing on the chopping block is learning how to make a progressive pomodoro web app, which really I am just using as a way to apply my learning Javascript in a cool project. I have basic knowledge in Javascript but haven't ramped it up since I stopped teaching myself last May. This I am going to accomplish by completing the FreeCodeCamp Javascript section along with some other tutorials in between.

Until next time!
